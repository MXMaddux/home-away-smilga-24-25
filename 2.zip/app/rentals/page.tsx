import React from "react";

function RentalsPage() {
  return <div>RentalsPage</div>;
}

export default RentalsPage;
