const FavoritesPage = () => {
  return <div>FavoritesPage</div>;
};

export default FavoritesPage;
