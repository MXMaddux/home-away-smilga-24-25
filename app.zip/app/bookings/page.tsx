function BookingsPage() {
  return <div>Bookings Page</div>;
}
export default BookingsPage;
