import React from "react";

function PropertiesPage() {
  return <div>PropertiesPage</div>;
}

export default PropertiesPage;
