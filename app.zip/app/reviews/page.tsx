import React from "react";

function ReviewsPage() {
  return <div>ReviewsPage</div>;
}

export default ReviewsPage;
